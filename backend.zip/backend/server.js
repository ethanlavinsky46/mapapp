//Basic express example with 'GET' route
const express = require("express");

const app = express();

app.use(express.json());

const port = 5000;

app.listen(port, () => console.log(`Server started on port ${port}`));

app.get("/api", (req, res) => {
  res.send({ express: "The route works." });
});
